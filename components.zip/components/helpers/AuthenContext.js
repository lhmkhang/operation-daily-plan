'use client'

import React, { createContext, useState, useEffect } from 'react';

export const AuthContext = createContext();

export const AuthProvider = ({ children }) => {
    const [user, setUser] = useState(null);

    // Hàm để cập nhật thông tin người dùng sau khi đăng nhập
    const login = (userData) => {
        setUser(userData);
    };

    // Hàm để đăng xuất
    const logout = () => {
        setUser(null);
    };

    return (
        <AuthContext.Provider value={{ user, login, logout }}>
            {children}
        </AuthContext.Provider>
    );
};
